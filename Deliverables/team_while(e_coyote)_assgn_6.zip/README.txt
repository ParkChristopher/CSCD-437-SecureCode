/***README***/

Need to know:
	-The C version of the project is compiled under linux and uses libraries specific to it.
	(compile: gcc -pedantic -Wall -Wextra -Werror)


