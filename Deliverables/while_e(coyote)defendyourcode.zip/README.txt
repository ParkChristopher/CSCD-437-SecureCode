/***Read Me***/

Team: While_e(coyote)
Chris Park								christopherpark@eagles.ewu.edu
Homero Gonzalez					hgonzalez1@eagles.ewu.edu
Travis Landers						travislanders@eagles.ewu.eagles

To Compile:

Java - Windows 10 - we just used the command line.

	Compile: <javac *javac>

C - Compiled using gcc on ubuntu (no regex.h in windows) 

	Compile: <gcc -pedantic -Wall -Wextra -Werror defend.c>