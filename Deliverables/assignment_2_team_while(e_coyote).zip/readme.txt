Team: while(e_coyote)
Members: Chris Park, Travis Landers, Homero Gonzalez

Shortcomings: In order to recompile the source code that the original Replicator.java file outputs, It had to be renamed from Replicator2.java back to Replicator.java so that the class name matched the file name. Not doing this resulted in a compilation error of Replicator2.java.